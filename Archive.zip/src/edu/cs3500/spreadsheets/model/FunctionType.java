package edu.cs3500.spreadsheets.model;

/**
 * Enumerates the different type of functions that are supported.
 */
enum FunctionType {
  SUM, PRODUCT, LT, CAT
}
