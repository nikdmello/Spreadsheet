package edu.cs3500.spreadsheets.model;

/**
 * Enumerates the different type of functions that are supported.
 */
public enum FunctionType {
  SUM, PRODUCT, LT, CAT
}
